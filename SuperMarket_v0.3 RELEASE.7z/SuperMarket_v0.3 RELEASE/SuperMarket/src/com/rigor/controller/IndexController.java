package com.rigor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class IndexController {
	
	@RequestMapping(value = { "/"}, method = RequestMethod.GET)
	public String homePage(ModelMap model) {
		return "Home";
	}

	@RequestMapping(value = { "/product"}, method = RequestMethod.GET)
	public String productsPage(ModelMap model) {
		return "Product";
	}

	@RequestMapping(value = "/grn", method = RequestMethod.GET)
	public String getGRNPage(ModelMap model) {
		return "Grn";
	}

	@RequestMapping(value = "/invoice", method = RequestMethod.GET)
	public String getInvoicePage(ModelMap model) {
		return "Invoice";
	}

	@RequestMapping(value = "/supplier", method = RequestMethod.GET)
	public String getSupplierPage(ModelMap model) {
		return "Supplier";
	}
}